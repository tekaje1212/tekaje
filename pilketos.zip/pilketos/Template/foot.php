<nav id="foot" class="navbar navbar-default navbar-fixed-bottom">
  <div class="container">
	    <p class="navbar-text">Copyright &copy; <?=date('Y'); ?> E-Pilketos SMK Muhammadiyah Bawang. </p>
	    <p id="alamat" class="navbar-text navbar-right">
	    Jl. Bawang-Sukorejo, Km. 01 Ds. Jlamprang, Kec. Bawang, Kab. Batang (51274)
	    </p>
  </div>
</nav>

<script src="Assets/js/jquery-3.1.0.min.js"></script>
<script src="Assets/js/bootstrap.min.js"></script>

<script>	
try {
	setTimeout(function(){
		console.clear();
		console.log("%cWelcome!", "color: #000; font-size:45px; font-weight: bold; font-family: Arial");
		console.log("%cAda perlu sesuatu di console?", "color: blue; font-size:25px; font-weight: bold; font-family: Arial");
		console.log("%cJangan paste disini, code yang tidak Anda mengerti.", "color: red; font-size:20px; font-weight: bold; font-family: Arial");
	}, 1000);
} catch(e) {

}
</script>

</body>
</html>