<?php  

session_start();
require_once 'Func/db.php';
require_once 'Func/pilih.php';
require_once 'Func/calon.php';
?>